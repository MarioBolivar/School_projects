 *  Mario Bolivar - Mjb160330
 *  Class: CE 3345.001
 *  Semester: Fall 2018
 *  Project #1: This program prompts the user to give a positive integer value N 
 *  and prints all primes up until N using the  �Sieve of Erotosthenes� algorithm.

IDE used: NetBeans


Thank you!