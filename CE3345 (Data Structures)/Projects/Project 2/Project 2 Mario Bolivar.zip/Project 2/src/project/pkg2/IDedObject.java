package project.pkg2;

/**
*
* @author Mario Bolivar - Mjb160330
*   IDedObject interface.
*
*/

public interface  IDedObject {
    int getID();
    void printID();

}