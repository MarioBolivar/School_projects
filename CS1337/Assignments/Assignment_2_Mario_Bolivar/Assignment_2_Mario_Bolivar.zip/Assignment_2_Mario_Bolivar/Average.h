#include <iostream>

using namespace std;

//Function Prototype
void averageFunc(double, int);