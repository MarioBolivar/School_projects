#include "Average.h"

// Function to find the average of the elements inside the array
void averageFunc(double sum, int size)
{
    double avg = 0;

    avg = sum / size;

    cout << "The average monthly sale is: " << avg << endl;

}