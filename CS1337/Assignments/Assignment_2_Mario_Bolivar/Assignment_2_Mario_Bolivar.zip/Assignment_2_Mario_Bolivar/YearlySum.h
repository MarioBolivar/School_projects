#include <iostream>

using namespace std;

//Function Prototype
double yearlysumFunc(double*,int);