#include <iostream>

using namespace std;

// Function Prototype
void meanFunc(int arrOriginal[], int arrSorted[], int size, int numSearch, int pos);