#include <iostream>

using namespace std;

// Function Prototype
int searchFunc(int [], int,int);
