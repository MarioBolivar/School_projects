#include <iostream>

using namespace std;

// Function Prototype
void sortFunc(int [], int);