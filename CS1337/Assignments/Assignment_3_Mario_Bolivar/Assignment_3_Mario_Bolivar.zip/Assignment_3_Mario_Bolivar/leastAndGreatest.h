#ifndef LEASTANDGREATEST_H
#define LEASTANDGREATEST_H

//Header file for the function to calculate the least 
// and greatest number of planes landed/departed
// and which month it happened in
#include <iostream>
#include "airportStruct.h"

using namespace std;

//Function prototype
void leastAndGreatest(Airport*,int);

#endif