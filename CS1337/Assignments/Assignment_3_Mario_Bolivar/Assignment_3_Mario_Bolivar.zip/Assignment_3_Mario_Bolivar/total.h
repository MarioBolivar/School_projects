#ifndef TOTAL_H
#define TOTAL_H

//Header file for the total number of planes departed/landed
#include <iostream>
#include "airportStruct.h"

using namespace std;

//Function prototype
void total(Airport*,int);

#endif