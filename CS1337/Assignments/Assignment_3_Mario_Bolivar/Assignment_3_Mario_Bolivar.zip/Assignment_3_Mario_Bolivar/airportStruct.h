#ifndef AIRPORTSTRUCT_H
#define AIRPORTSTRUCT_H

#include <iostream>

using namespace std;

struct Airport{

    int planesLanded;
    int planesDeparted;
    int maxPlanes;
    int minPlanes;

};

#endif