#ifndef AVGPLANESDEPARTED_H
#define AVGPLANESDEPARTED_H

//Header file for the average monthly planes departed function
#include <iostream>
#include "airportStruct.h"

using namespace std;

//Avg monthly planes departed function prototype
void avgPlanesDeparted(Airport*,int);

#endif