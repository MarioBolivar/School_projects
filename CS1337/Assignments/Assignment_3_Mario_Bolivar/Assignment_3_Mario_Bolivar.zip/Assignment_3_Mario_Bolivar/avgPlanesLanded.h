#ifndef AVGPLANESLANDED_H
#define AVGPLANESLANDED_H

//Header file for the average monthly planes landed function
#include <iostream>
#include "airportStruct.h"

using namespace std;

//Avg monthly planes landed function prototype
void avgPlanesLanded(Airport*, int);

#endif